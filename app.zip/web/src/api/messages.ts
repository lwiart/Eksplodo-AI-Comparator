/** Partagé avec la saisie : le même texte s'affiche avant l'envoi et après un refus du serveur. */
export const AUDIT_URL_MESSAGE = 'L’URL doit commencer par https:// et tenir en 300 caractères.';

const MESSAGES: Record<string, string> = {
  unauthorized: 'Votre session a expiré. Reconnectez-vous.',
  invalid_credentials: 'E-mail ou mot de passe incorrect.',
  forbidden: "Vous n'avez pas les droits nécessaires pour cette action.",
  validation: 'Certaines informations sont invalides. Vérifiez la saisie.',
  rate_limited: 'Trop de tentatives. Réessayez dans quelques minutes.',
  invitation_invalid: "Ce lien n'est plus valide. Demandez-en un nouveau.",
  invalid_password: 'Le mot de passe actuel est incorrect.',
  weak_password: 'Le mot de passe doit contenir au moins 12 caractères.',
  email_taken: 'Un compte existe déjà avec cet e-mail.',
  user_not_active: "Ce compte n'est pas actif.",
  user_not_invited: "Ce compte n'est pas en attente d'activation : l'invitation ne peut pas être renvoyée.",
  user_not_activated: "Ce compte n'a pas encore été activé : renvoyez plutôt l'invitation.",
  last_admin: "Impossible : c'est le dernier Admin actif, il doit en rester au moins un.",
  key_missing: "Aucune clé n'est enregistrée pour ce fournisseur : saisissez-la d'abord.",
  key_unreadable: 'La clé enregistrée est illisible (la clé maîtresse du serveur a changé) : ressaisissez-la.',
  provider_error: 'Le fournisseur a refusé la requête.',
  provider_name_taken: 'Un fournisseur porte déjà ce nom.',
  model_exists: 'Ce modèle est déjà dans le catalogue pour ce fournisseur.',
  file_too_large: 'Fichier trop volumineux : 10 Mo au plus.',
  unsupported_file_type: 'Type de fichier non pris en charge : PNG, JPEG, WebP ou PDF.',
  too_many_attachments: 'Dix pièces jointes au plus par test.',
  model_unavailable: 'Ce modèle est indisponible (inactif, ou fournisseur sans clé utilisable).',
  unsupported_attachment: 'Ce modèle ne gère pas une des pièces jointes du test.',
  suite_not_found: "Cette suite n'existe plus. Rechargez la page.",
  judge_required: 'Un des tests est noté par le juge : choisissez un modèle juge.',
  budget_exceeded: 'Le coût maximal estimé dépasse le plafond fixé.',
  run_not_active: "Cette série n'est plus en cours.",
  run_not_paused: "Cette série n'est pas en pause.",
  run_too_large: 'Série trop grande : 5 000 appels au plus.',
  test_archived: 'Ce test est archivé : aucune pièce jointe ne peut y être ajoutée.',
  suite_name_taken: 'Une suite porte déjà ce nom.',
  test_not_found: 'Un des tests choisis n’existe plus. Rechargez la page.',
  model_not_found: 'Ce modèle est introuvable ou désactivé : choisissez-en un autre.',
  not_rescorable: 'Ce test n’est pas noté par le juge : sa note ne peut pas être relancée.',
  invalid_score: 'La note doit être un nombre entier compris entre 0 et 100.',
  result_not_scorable: 'Seul un résultat terminé peut recevoir une note imposée.',
  question_not_ready: 'Toutes les réponses de cette question ne sont pas encore arrivées. Réessayez plus tard.',
  verdict_model_not_in_run: 'Le modèle d’un verdict ne fait pas partie de cette série.',
  invalid_audit_url: AUDIT_URL_MESSAGE,
  not_found: "Cet élément n'existe plus. Rechargez la page.",
  csrf: 'Votre session a expiré, rechargez la page.',
  internal: "Une erreur inattendue s'est produite. Réessayez dans quelques instants.",
  network: 'Le serveur ne répond pas. Vérifiez votre connexion puis réessayez.',
};

const DEFAULT_MESSAGE = 'Une erreur est survenue. Réessayez.';

export function messageFor(code: string): string {
  return Object.hasOwn(MESSAGES, code) ? MESSAGES[code]! : DEFAULT_MESSAGE;
}

/** Comme `messageForError`, mais le refus d'une clé mal formée garde le message précis du serveur. */
export function messageForKeyError(err: unknown): string {
  const { code, message } = (err ?? {}) as { code?: unknown; message?: unknown };
  if (code === 'validation' && typeof message === 'string' && message.startsWith('Clé API invalide')) return message;
  return messageForError(err);
}

/**
 * Erreur d'une notation manuelle : les refus de validation du serveur (« Notez toutes les réponses de la question »,
 * « Lettre inconnue : X ») sont déjà en français et précis, on les garde.
 */
export function messageForScoreError(err: unknown): string {
  const { code, message } = (err ?? {}) as { code?: unknown; message?: unknown };
  if (code === 'validation' && typeof message === 'string' && message !== '') return message;
  return messageForError(err);
}

/** Message à afficher pour une erreur quelconque (ApiError ou autre). */
export function messageForError(err: unknown): string {
  const { code, reference } = (err ?? {}) as { code?: unknown; reference?: unknown };
  if (code === 'internal' && typeof reference === 'string' && reference !== '') {
    return `${messageFor(code)} Si le problème persiste, communiquez la référence ${reference} à votre administrateur.`;
  }
  return typeof code === 'string' ? messageFor(code) : DEFAULT_MESSAGE;
}
